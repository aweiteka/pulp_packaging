.. Pulp Docker documentation master file, created by
   sphinx-quickstart on Wed May 21 09:44:51 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Pulp Docker Support
===================

This project adds support to Pulp for managing Docker images.

Contents:

.. toctree::
   :maxdepth: 2

   installation
   concepts
   recipes


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

