Importer
========

ID: ``docker_importer``

Configuration
-------------

The following options are available to the docker importer configuration.

``mask_id``
 Supported only as an override config option to a repository upload command, when
 this option is used, the upload command will skip adding given image and
 any ancestors of that image to the repository.

